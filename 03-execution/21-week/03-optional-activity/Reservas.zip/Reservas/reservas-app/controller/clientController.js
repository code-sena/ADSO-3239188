const ClientController = {
  clients: [],
  nextId: 1,
 
  getAll() {
    return this.clients;
  },

  getById(id) {
    return this.clients.find((c) => c.id === id);
  },

  create(data) {
    this.clients.push(
      new Client(this.nextId++, data.type_document, data.document, data.name, data.address, data.phone, data.email)
    );
  },

  update(id, data) {
    const index = this.clients.findIndex((c) => c.id === id);
    this.clients[index] = new Client(id, data.type_document, data.document, data.name, data.address, data.phone, data.email);
  },

  delete(id) {
    if (ReservationController.getAll().some((r) => r.client_id === id)) return false;
    this.clients = this.clients.filter((c) => c.id !== id);
    return true;
  },
};
