const ReservationController = {
  reservations: [],
  nextId: 1,

  getAll() {
    return this.reservations;
  },

  getById(id) {
    return this.reservations.find((r) => r.id === id);
  },

  create(data) {
    this.reservations.push(new Reservation(this.nextId++, data.name, data.description, data.client_id));
  },

  update(id, data) {
    const index = this.reservations.findIndex((r) => r.id === id);
    this.reservations[index] = new Reservation(id, data.name, data.description, data.client_id);
  },

  delete(id) {
    this.reservations = this.reservations.filter((r) => r.id !== id);
  },
};
