// Mirrors the "client" table of the database
export class Client {
  constructor(id, typeDocument, document, name, address, phone, email) {
    this.id = id;
    this.typeDocument = typeDocument;
    this.document = document;
    this.name = name;
    this.address = address;
    this.phone = phone;
    this.email = email;
  }
}
