// Mirrors the "reservation" table of the database
export class Reservation {
  constructor(id, name, description, clientId) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.clientId = clientId; // Foreign key -> Client.id
  }
}
