import { AppController } from "./controller/appController.js";

const controller = new AppController();

// ---------- DOM elements ----------
const clientForm = document.getElementById("client-form");
const reservationForm = document.getElementById("reservation-form");
const clientList = document.getElementById("client-list");
const reservationList = document.getElementById("reservation-list");
const clientSelect = document.getElementById("reservation-client");

// ---------- UI builders ----------
function createItem(title, details) {
  const li = document.createElement("li");
  li.className = "item";

  const info = document.createElement("div");
  const strong = document.createElement("strong");
  strong.textContent = title;
  const small = document.createElement("small");
  small.textContent = details;
  info.append(strong, small);

  li.appendChild(info);
  return li;
}

function createEmptyMessage(text) {
  const li = document.createElement("li");
  li.className = "empty";
  li.textContent = text;
  return li;
}

function createDeleteButton(onClick) {
  const button = document.createElement("button");
  button.className = "btn-delete";
  button.textContent = "Eliminar";
  button.addEventListener("click", onClick);
  return button;
}

// ---------- Render (updates the view from controller data) ----------
function renderClients() {
  clientList.innerHTML = "";
  clientSelect.innerHTML = '<option value="">Selecciona un cliente</option>';

  const clients = controller.getClients();
  if (clients.length === 0) {
    clientList.appendChild(createEmptyMessage("Aún no hay clientes registrados."));
  }

  for (const client of clients) {
    const li = createItem(
      client.name,
      `${client.typeDocument} ${client.document} · ${client.phone} · ${client.email}`
    );
    li.appendChild(createDeleteButton(() => {
      try {
        controller.deleteClient(client.id);
        renderAll();
      } catch (error) {
        alert(error.message);
      }
    }));
    clientList.appendChild(li);

    const option = document.createElement("option");
    option.value = String(client.id);
    option.textContent = client.name;
    clientSelect.appendChild(option);
  }
}

function renderReservations() {
  reservationList.innerHTML = "";

  const reservations = controller.getReservations();
  if (reservations.length === 0) {
    reservationList.appendChild(createEmptyMessage("Aún no hay citas agendadas."));
  }

  for (const reservation of reservations) {
    const li = createItem(
      reservation.name,
      `${reservation.description} · Cliente: ${controller.getClientName(reservation.clientId)}`
    );
    li.appendChild(createDeleteButton(() => {
      controller.deleteReservation(reservation.id);
      renderAll();
    }));
    reservationList.appendChild(li);
  }
}

function renderAll() {
  renderClients();
  renderReservations();
}

// ---------- Events (connect View -> Controller) ----------
clientForm.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    controller.createClient(
      document.getElementById("client-type-document").value,
      document.getElementById("client-document").value,
      document.getElementById("client-name").value,
      document.getElementById("client-address").value,
      document.getElementById("client-phone").value,
      document.getElementById("client-email").value
    );
    clientForm.reset();
    renderAll();
    alert("Cliente agregado correctamente.");
  } catch (error) {
    alert(error.message);
  }
});

reservationForm.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    controller.createReservation(
      document.getElementById("reservation-name").value,
      document.getElementById("reservation-description").value,
      Number(clientSelect.value)
    );
    reservationForm.reset();
    renderAll();
    alert("Cita agendada correctamente.");
  } catch (error) {
    alert(error.message);
  }
});

// ---------- Start: load data with AJAX, then render ----------
async function init() {
  try {
    await controller.loadData();
  } catch (error) {
    alert(error.message);
  }
  renderAll();
}

init();
