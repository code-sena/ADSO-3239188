import { Client } from "../model/client.js";
import { Reservation } from "../model/reservation.js";

// Business logic: in-memory "tables" + validations + AJAX loading
export class AppController {
  constructor() {
    this.clients = [];
    this.reservations = [];
    this.nextClientId = 1;
    this.nextReservationId = 1;
  }

  // ---------- AJAX ----------
  // Requests a JSON file from the server without reloading the page
  async fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("No se pudieron cargar los datos desde " + url);
    }
    return response.json();
  }

  // Loads the initial data (our "database") using AJAX
  async loadData() {
    const clientsData = await this.fetchJson("data/clients.json");
    const reservationsData = await this.fetchJson("data/reservations.json");

    // Convert plain JSON objects into model instances
    this.clients = clientsData.map(
      (c) => new Client(c.id, c.typeDocument, c.document, c.name, c.address, c.phone, c.email)
    );
    this.reservations = reservationsData.map(
      (r) => new Reservation(r.id, r.name, r.description, r.clientId)
    );

    // Continue the auto-increment after the highest loaded id
    this.nextClientId = Math.max(0, ...this.clients.map((c) => c.id)) + 1;
    this.nextReservationId = Math.max(0, ...this.reservations.map((r) => r.id)) + 1;
  }

  // ---------- CLIENT ----------
  createClient(typeDocument, document, name, address, phone, email) {
    if (!typeDocument || !document.trim() || !name.trim() ||
        !address.trim() || !phone.trim() || !email.trim()) {
      throw new Error("Todos los campos del cliente son obligatorios.");
    }
    if (!email.includes("@")) {
      throw new Error("El correo electrónico no es válido.");
    }
    if (this.clients.some((c) => c.document === document)) {
      throw new Error("Ya existe un cliente con ese documento.");
    }
    const client = new Client(this.nextClientId++, typeDocument, document, name, address, phone, email);
    this.clients.push(client);
    return client;
  }

  getClients() {
    return this.clients;
  }

  deleteClient(id) {
    if (this.reservations.some((r) => r.clientId === id)) {
      throw new Error("No se puede eliminar un cliente que tiene reservas.");
    }
    this.clients = this.clients.filter((c) => c.id !== id);
  }

  // ---------- RESERVATION ----------
  createReservation(name, description, clientId) {
    if (!name.trim() || !description.trim()) {
      throw new Error("El nombre y la descripción de la reserva son obligatorios.");
    }
    // Key rule: the client must exist before creating a reservation
    if (!this.clients.some((c) => c.id === clientId)) {
      throw new Error("El cliente seleccionado no existe.");
    }
    const reservation = new Reservation(this.nextReservationId++, name, description, clientId);
    this.reservations.push(reservation);
    return reservation;
  }

  getReservations() {
    return this.reservations;
  }

  deleteReservation(id) {
    this.reservations = this.reservations.filter((r) => r.id !== id);
  }

  getClientName(clientId) {
    const client = this.clients.find((c) => c.id === clientId);
    return client ? client.name : "Desconocido";
  }
}
