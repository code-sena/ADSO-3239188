// Representación de POO => Clase Reserva
export class Reservation {
    constructor(
        public id: number,
        public name: string,
        public description: string,
        public client_id: number // Enlace o relación con el ID del Cliente
    ) {}
}
