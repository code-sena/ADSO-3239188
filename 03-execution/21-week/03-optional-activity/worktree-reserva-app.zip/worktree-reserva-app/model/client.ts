// Representación de POO => Clase Base (Padre)
export class Persona {
    constructor(
        public id: number,
        public name: string
    ) {}
}

// Herencia: La clase Client hereda de Persona
export class Client extends Persona {
    constructor(
        id: number,
        name: string,
        public type_document: string,
        public document: string,
        public address: string, // Agregado obligatorio
        public phone: string,   // Agregado obligatorio
        public email: string    // Agregado obligatorio
    ) {
        super(id, name);
    }
}
