import { Reservation } from '../model/reservation';

// Controller Bussines Logic que procesará el motor V8 a alta velocidad
export class ReservationController {
    public reservations: Reservation[] = []; // BD: Array que simula la base de datos de reservas

    // CRUD: Create (Lógica de Negocio)
    create(item: Reservation): boolean {
        // Algorítmia usando operadores relacionales (===, <=) y lógicos (|| que es "or")
        if (item.name.trim() === "" || item.client_id <= 0) {
            return false; // Regla: No permite nombres vacíos ni IDs inválidos
        }
        this.reservations.push(item); // Guarda la reserva
        return true;
    }

    listAll(): Reservation[] { return this.reservations; }
}
