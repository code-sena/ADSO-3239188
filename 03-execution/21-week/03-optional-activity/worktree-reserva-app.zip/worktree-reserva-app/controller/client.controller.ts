import { Client } from '../model/client';

export class ClientController {
    public clients: Client[] = []; // BD: Array que simula la base de datos de clientes

    // CRUD: Create (Lógica de Negocio)
    create(item: Client): boolean {
        // Algorítmia: Validar que los campos clave no estén vacíos
        if (item.name.trim() === "" || item.document.trim() === "") {
            return false; // Si no cumple la regla de negocio, rechaza
        }
        this.clients.push(item); // Guarda el cliente en la BD simulada
        return true;
    }

    listAll(): Client[] { return this.clients; }
}
