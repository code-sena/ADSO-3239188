// controller/reservation/reservation.controller.js
// Controlador: valida la entrada y conecta las rutas (vista) con el modelo

const ReservationModel = require('../../model/reservation/reservation.model');
const ClientModel = require('../../model/client/client.model');

function listReservations(req, res) {
  res.json(ReservationModel.getAll());
}

function getReservation(req, res) {
  const reservation = ReservationModel.getById(req.params.id);
  if (!reservation) return res.status(404).json({ error: 'Reserva no encontrada' });
  res.json(reservation);
}

function createReservation(req, res) {
  const { name, description, client_id } = req.body;

  if (!name || !description || !client_id) {
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }

  const client = ClientModel.getById(client_id);
  if (!client) {
    return res.status(400).json({ error: 'El cliente indicado no existe' });
  }

  const reservation = ReservationModel.create({ name, description, client_id });
  res.status(201).json(reservation);
}

function updateReservation(req, res) {
  const updated = ReservationModel.update(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Reserva no encontrada' });
  res.json(updated);
}

function deleteReservation(req, res) {
  const ok = ReservationModel.remove(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Reserva no encontrada' });
  res.json({ message: 'Reserva eliminada' });
}

module.exports = {
  listReservations,
  getReservation,
  createReservation,
  updateReservation,
  deleteReservation
};
