// controller/client/client.controller.js
// Controlador: valida la entrada y conecta las rutas (vista) con el modelo

const ClientModel = require('../../model/client/client.model');

function listClients(req, res) {
  res.json(ClientModel.getAll());
}

function getClient(req, res) {
  const client = ClientModel.getById(req.params.id);
  if (!client) return res.status(404).json({ error: 'Cliente no encontrado' });
  res.json(client);
}

function createClient(req, res) {
  const { type_document, document, name, address, phone, email } = req.body;

  if (!type_document || !document || !name || !address || !phone || !email) {
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }

  const client = ClientModel.create({ type_document, document, name, address, phone, email });
  res.status(201).json(client);
}

function updateClient(req, res) {
  const updated = ClientModel.update(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Cliente no encontrado' });
  res.json(updated);
}

function deleteClient(req, res) {
  const ok = ClientModel.remove(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Cliente no encontrado' });
  res.json({ message: 'Cliente eliminado' });
}

module.exports = { listClients, getClient, createClient, updateClient, deleteClient };
