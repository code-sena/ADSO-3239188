// assets/library/app.js
// Orquesta tabs, eventos de formularios y refresco de tablas (usa Client/ReservationView)

let allClients = [];
let allReservations = [];

// --- Tabs ---
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.add('active');
  });
});

// --- Carga inicial ---
async function loadClients() {
  allClients = await ClientView.fetchAll();
  ClientView.renderTable(allClients);
  ClientView.renderClientOptions(allClients);
}

async function loadReservations() {
  allReservations = await ReservationView.fetchAll();
  ReservationView.renderTable(allReservations, allClients);
}

async function loadAll() {
  await loadClients();
  await loadReservations();
}

// --- Formulario Cliente ---
const clientForm = document.getElementById('client-form');
const clientCancelBtn = document.getElementById('client-cancel-btn');

clientForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('client-id').value;
  const data = {
    type_document: document.getElementById('client-type-document').value,
    document: document.getElementById('client-document').value,
    name: document.getElementById('client-name').value,
    address: document.getElementById('client-address').value,
    phone: document.getElementById('client-phone').value,
    email: document.getElementById('client-email').value
  };

  if (id) {
    await ClientView.update(id, data);
  } else {
    await ClientView.create(data);
  }

  resetClientForm();
  await loadAll();
});

clientCancelBtn.addEventListener('click', resetClientForm);

function resetClientForm() {
  clientForm.reset();
  document.getElementById('client-id').value = '';
  document.getElementById('client-submit-btn').textContent = 'Guardar cliente';
  clientCancelBtn.classList.add('hidden');
}

document.getElementById('clients-tbody').addEventListener('click', async (e) => {
  const id = e.target.dataset.id;
  if (!id) return;

  if (e.target.classList.contains('btn-edit')) {
    const client = allClients.find(c => c.id === Number(id));
    if (!client) return;
    document.getElementById('client-id').value = client.id;
    document.getElementById('client-type-document').value = client.type_document;
    document.getElementById('client-document').value = client.document;
    document.getElementById('client-name').value = client.name;
    document.getElementById('client-address').value = client.address;
    document.getElementById('client-phone').value = client.phone;
    document.getElementById('client-email').value = client.email;
    document.getElementById('client-submit-btn').textContent = 'Actualizar cliente';
    clientCancelBtn.classList.remove('hidden');
  }

  if (e.target.classList.contains('btn-delete')) {
    if (confirm('¿Eliminar este cliente?')) {
      await ClientView.remove(id);
      await loadAll();
    }
  }
});

// --- Formulario Reserva ---
const reservationForm = document.getElementById('reservation-form');
const reservationCancelBtn = document.getElementById('reservation-cancel-btn');

reservationForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('reservation-id').value;
  const data = {
    name: document.getElementById('reservation-name').value,
    description: document.getElementById('reservation-description').value,
    client_id: document.getElementById('reservation-client-id').value
  };

  if (id) {
    await ReservationView.update(id, data);
  } else {
    await ReservationView.create(data);
  }

  resetReservationForm();
  await loadReservations();
});

reservationCancelBtn.addEventListener('click', resetReservationForm);

function resetReservationForm() {
  reservationForm.reset();
  document.getElementById('reservation-id').value = '';
  document.getElementById('reservation-submit-btn').textContent = 'Guardar reserva';
  reservationCancelBtn.classList.add('hidden');
}

document.getElementById('reservations-tbody').addEventListener('click', async (e) => {
  const id = e.target.dataset.id;
  if (!id) return;

  if (e.target.classList.contains('btn-edit-res')) {
    const reservation = allReservations.find(r => r.id === Number(id));
    if (!reservation) return;
    document.getElementById('reservation-id').value = reservation.id;
    document.getElementById('reservation-name').value = reservation.name;
    document.getElementById('reservation-description').value = reservation.description;
    document.getElementById('reservation-client-id').value = reservation.client_id;
    document.getElementById('reservation-submit-btn').textContent = 'Actualizar reserva';
    reservationCancelBtn.classList.remove('hidden');
  }

  if (e.target.classList.contains('btn-delete-res')) {
    if (confirm('¿Eliminar esta reserva?')) {
      await ReservationView.remove(id);
      await loadReservations();
    }
  }
});

// --- Inicio ---
loadAll();
