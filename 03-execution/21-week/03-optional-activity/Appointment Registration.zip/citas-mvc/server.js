// server.js
// Punto de entrada: servidor Express + definición de rutas (API) + servicio de la Vista (archivos estáticos)

const express = require('express');
const path = require('path');

const clientController = require('./controller/client/client.controller');
const reservationController = require('./controller/reservation/reservation.controller');

const app = express();
const PORT = 3000;

app.use(express.json());

// --- Rutas API Client ---
app.get('/api/clients', clientController.listClients);
app.get('/api/clients/:id', clientController.getClient);
app.post('/api/clients', clientController.createClient);
app.put('/api/clients/:id', clientController.updateClient);
app.delete('/api/clients/:id', clientController.deleteClient);

// --- Rutas API Reservation ---
app.get('/api/reservations', reservationController.listReservations);
app.get('/api/reservations/:id', reservationController.getReservation);
app.post('/api/reservations', reservationController.createReservation);
app.put('/api/reservations/:id', reservationController.updateReservation);
app.delete('/api/reservations/:id', reservationController.deleteReservation);

// --- Vista (archivos estáticos: HTML, CSS, JS de assets) ---
app.use(express.static(path.join(__dirname)));

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
