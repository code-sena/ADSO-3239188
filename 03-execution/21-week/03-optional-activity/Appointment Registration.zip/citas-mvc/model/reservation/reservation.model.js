// model/reservation/reservation.model.js
// Modelo: acceso y manejo de datos de Reservation (persistidos en archivo JSON)

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'reservations.json');

function readAll() {
  if (!fs.existsSync(DB_PATH)) return [];
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  return raw ? JSON.parse(raw) : [];
}

function writeAll(reservations) {
  fs.writeFileSync(DB_PATH, JSON.stringify(reservations, null, 2));
}

function getAll() {
  return readAll();
}

function getById(id) {
  return readAll().find(r => r.id === Number(id));
}

function getByClientId(clientId) {
  return readAll().filter(r => r.client_id === Number(clientId));
}

function create(data) {
  const reservations = readAll();
  const newId = reservations.length ? Math.max(...reservations.map(r => r.id)) + 1 : 1;
  const reservation = {
    id: newId,
    name: data.name,
    description: data.description,
    client_id: Number(data.client_id)
  };
  reservations.push(reservation);
  writeAll(reservations);
  return reservation;
}

function update(id, data) {
  const reservations = readAll();
  const idx = reservations.findIndex(r => r.id === Number(id));
  if (idx === -1) return null;
  reservations[idx] = { ...reservations[idx], ...data, id: reservations[idx].id };
  writeAll(reservations);
  return reservations[idx];
}

function remove(id) {
  const reservations = readAll();
  const filtered = reservations.filter(r => r.id !== Number(id));
  writeAll(filtered);
  return filtered.length !== reservations.length;
}

module.exports = { getAll, getById, getByClientId, create, update, remove };
