// model/client/client.model.js
// Modelo: acceso y manejo de datos de Client (persistidos en archivo JSON como "base de datos" simple)

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'clients.json');

function readAll() {
  if (!fs.existsSync(DB_PATH)) return [];
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  return raw ? JSON.parse(raw) : [];
}

function writeAll(clients) {
  fs.writeFileSync(DB_PATH, JSON.stringify(clients, null, 2));
}

function getAll() {
  return readAll();
}

function getById(id) {
  return readAll().find(c => c.id === Number(id));
}

function create(data) {
  const clients = readAll();
  const newId = clients.length ? Math.max(...clients.map(c => c.id)) + 1 : 1;
  const client = {
    id: newId,
    type_document: data.type_document,
    document: data.document,
    name: data.name,
    address: data.address,
    phone: data.phone,
    email: data.email
  };
  clients.push(client);
  writeAll(clients);
  return client;
}

function update(id, data) {
  const clients = readAll();
  const idx = clients.findIndex(c => c.id === Number(id));
  if (idx === -1) return null;
  clients[idx] = { ...clients[idx], ...data, id: clients[idx].id };
  writeAll(clients);
  return clients[idx];
}

function remove(id) {
  const clients = readAll();
  const filtered = clients.filter(c => c.id !== Number(id));
  writeAll(filtered);
  return filtered.length !== clients.length;
}

module.exports = { getAll, getById, create, update, remove };
