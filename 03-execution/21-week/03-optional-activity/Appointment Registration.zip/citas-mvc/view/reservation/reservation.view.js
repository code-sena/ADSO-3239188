// view/reservation/reservation.view.js
// Vista: interacción con el usuario y llamadas AJAX a la API de reservas

const ReservationView = {
  async fetchAll() {
    const res = await fetch('/api/reservations');
    return res.json();
  },

  async create(data) {
    const res = await fetch('/api/reservations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async update(id, data) {
    const res = await fetch(`/api/reservations/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async remove(id) {
    const res = await fetch(`/api/reservations/${id}`, { method: 'DELETE' });
    return res.json();
  },

  renderTable(reservations, clients) {
    const tbody = document.getElementById('reservations-tbody');
    tbody.innerHTML = '';
    reservations.forEach(r => {
      const client = clients.find(c => c.id === r.client_id);
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${r.id}</td>
        <td>${r.name}</td>
        <td>${r.description}</td>
        <td>${client ? client.name : 'N/A'}</td>
        <td>
          <button class="btn-edit-res" data-id="${r.id}">Editar</button>
          <button class="btn-delete-res" data-id="${r.id}">Eliminar</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }
};
