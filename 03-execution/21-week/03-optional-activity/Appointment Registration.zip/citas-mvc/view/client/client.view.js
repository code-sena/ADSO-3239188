// view/client/client.view.js
// Vista: interacción con el usuario y llamadas AJAX a la API de clientes

const ClientView = {
  async fetchAll() {
    const res = await fetch('/api/clients');
    return res.json();
  },

  async create(data) {
    const res = await fetch('/api/clients', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async update(id, data) {
    const res = await fetch(`/api/clients/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async remove(id) {
    const res = await fetch(`/api/clients/${id}`, { method: 'DELETE' });
    return res.json();
  },

  renderTable(clients) {
    const tbody = document.getElementById('clients-tbody');
    tbody.innerHTML = '';
    clients.forEach(c => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${c.id}</td>
        <td>${c.type_document}</td>
        <td>${c.document}</td>
        <td>${c.name}</td>
        <td>${c.address}</td>
        <td>${c.phone}</td>
        <td>${c.email}</td>
        <td>
          <button class="btn-edit" data-id="${c.id}">Editar</button>
          <button class="btn-delete" data-id="${c.id}">Eliminar</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  },

  renderClientOptions(clients) {
    const select = document.getElementById('reservation-client-id');
    const currentValue = select.value;
    select.innerHTML = '<option value="">Seleccione un cliente</option>';
    clients.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = `${c.name} (${c.document})`;
      select.appendChild(opt);
    });
    if (currentValue) select.value = currentValue;
  }
};
